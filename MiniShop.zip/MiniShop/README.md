MiniShop

در این پروژه سعی بر طراحی یک فروشگاه اینترنتی کوچک شده است و در ساخت ان از ابزار های html و  css  استفاده کرده ام

این پروژه صرفا دانشگاهی بوده و به همین منظور انجام شده است 

فایل های مریوطه
MiniShop / index.html product.html cart.html about.html Css/style.css assets/images README.md


عرفان اقایی
 
MiniShop | ErfanAghaee



